/* ============================================================
   facilityRates.js - ONE canonical facility-code -> factor table
   Source: 03_Home_Financing_Manual_DSR.txt section 4 (List!D:E),
   reconciled per credit_card.txt section 8 point 2:
   unknown facility -> factor 1 (use CCRIS instalment as-is).
   ============================================================ */
(function () {
  'use strict';
  window.Engine = window.Engine || {};

  var FACILITY_FACTORS = {
    CRDTCARD: 0.05,       // credit card: 5% of outstanding, min RM50
    HLFNNNPS: 1,
    HLFNPRSR: 1,
    HRPCNSCG: 1,
    HRPCSCGD: 1,
    HSLNFNCE: 1,          // housing loan / financing
    ISPJTFNG: 1,
    ISPWNBKG: 0,          // pawn broking: excluded
    MICROFNCE: 1,
    OHRPCREC: 1,
    OTLNFNCE: 1,          // other loan financing
    OVRDRAFT: 0.0077529,  // overdraft: 0.77529% of LIMIT
    PCPASCAR: 1,
    PELNFNCE: 1,
    RVVGCRDT: 1,
    SHMARGIN: 0,          // share margin: excluded
    SOFTLN: 1,
    STLNFNCE: 1,
    TEMPOVDT: 0.0077529,  // temporary overdraft: on LIMIT
    NHEDFNCE: 1,
    PELNFNSA: 1,
    OTHER: 1              // manual "other commitment" rows
  };

  var OVERDRAFT_RATE = 0.0077529;
  var CARD_RATE = 0.05;

  function facilityFactor(code) {
    var c = String(code || '').toUpperCase().trim();
    if (Object.prototype.hasOwnProperty.call(FACILITY_FACTORS, c)) {
      return FACILITY_FACTORS[c];
    }
    return 1; // default per PF/HF spec: commitment = CCRIS instalment as-is
  }

  /** Facilities counted in the unsecured new-commitment sum (Excel G125):
      the line must be one of these facilities AND collateral = "CLEAN". */
  var UNSECURED_FACILITIES = {
    CRDTCARD: 1, OTLNFNCE: 1, OVRDRAFT: 1, PELNFNCE: 1,
    RVVGCRDT: 1, STLNFNCE: 1, NHEDFNCE: 1, PELNFNSA: 1
  };
  function isUnsecuredLine(row) {
    var f = String(row.facility || '').toUpperCase().trim();
    var col = String(row.collateral || '').toUpperCase().trim();
    return col === 'CLEAN' &&
      Object.prototype.hasOwnProperty.call(UNSECURED_FACILITIES, f);
  }

  /** Stress-test % incremental by collateral type (Excel List!A28:B32).
      Fixed table - not a user input. Unknown collateral -> 0 (IFNA(...,0)).

      Excel T: IF(F="", 0, VLOOKUP(collateral, List!A28:B32, 2, 0)) - written
      as IF(F17=List!$D$3,...) where List!D3 is the BLANK cell above the
      facility list (the CRDTCARD label is missing from D3; only its 0.05
      rate survives at E3). So the zero-branch fires for a blank facility,
      i.e. an empty row - NOT for credit cards. A floating CRDTCARD line does
      take its collateral uplift. */
  var STRESS_FACTORS = {
    'PROPERTIES': 0.05,
    'CLEAN': 0.008928571428571428,
    'MOTOR V (JPJ)': 0.016544117647058824,
    'UNIT TRUST': 0.02083333333333314
  };
  function stressFactorFor(row) {
    if (!String(row.facility || '').trim()) return 0;   // F = List!D3 (blank)
    var col = String(row.collateral || '').toUpperCase().replace(/\s+/g, ' ').trim();
    return STRESS_FACTORS[col] || 0;
  }

  Engine.FACILITY_FACTORS = FACILITY_FACTORS;
  Engine.OVERDRAFT_RATE = OVERDRAFT_RATE;
  Engine.CARD_RATE = CARD_RATE;
  Engine.facilityFactor = facilityFactor;
  Engine.isUnsecuredLine = isUnsecuredLine;
  Engine.STRESS_FACTORS = STRESS_FACTORS;
  Engine.stressFactorFor = stressFactorFor;
})();
