/* ============================================================
   dsrThresholds.js - DSR pass/fail tables + verdict strings
   Sources: 03_Home_Financing_Manual_DSR.txt sections 4 & 6,
            04_PF_CCRIS_DSR_Evaluation_Report.txt sections 6 & 8,
            credit_card.txt section 5 step 6.
   ============================================================ */
(function () {
  'use strict';
  window.Engine = window.Engine || {};

  var VERDICT = {
    OK: 'OK',
    DSR_BURST: 'DSR BURST',
    NOT_ELIGIBLE: 'NOT ELIGIBLE',
    EXCEED_LIMIT: 'EXCEED LIMIT',
    ELIGIBLE: 'ELIGIBLE'
  };

  /** Home Financing DSR threshold (fraction), income-banded.
      NORMAL  (List Z2:AA6): <3000 fail; >=3000 70%; >=5000 80%; >=16500 85%
      BIZMAN  (List AC3:AD5): >=5000 80%; >=16500 85% */
  function hfThreshold(grossIncome, customerType) {
    if (customerType === 'BIZMAN') {
      if (grossIncome >= 16500) return 0.85;
      if (grossIncome >= 5000) return 0.80;
      return 0;
    }
    if (grossIncome >= 16500) return 0.85;
    if (grossIncome >= 5000) return 0.80;
    if (grossIncome >= 3000) return 0.70;
    return 0;
  }

  /** HF verdict. dsr as fraction. */
  function hfVerdict(grossIncome, customerType, dsr) {
    var thr = hfThreshold(grossIncome, customerType);
    if (thr === 0) return { verdict: VERDICT.NOT_ELIGIBLE, threshold: 0 };
    return {
      verdict: dsr <= thr ? VERDICT.OK : VERDICT.DSR_BURST,
      threshold: thr
    };
  }

  /** Personal Financing DSR threshold (fraction) + NDI minimum.
      TYPE B: income <10000 -> 70%, >=10000 -> 75%, NDI >= 1500
      TYPE A: 60% across the board, NDI >= 2000 */
  function pfThreshold(grossIncome, customerClass) {
    if (customerClass === 'TYPE B') {
      return { threshold: grossIncome < 10000 ? 0.70 : 0.75, ndiMin: 1500 };
    }
    return { threshold: 0.60, ndiMin: 2000 };
  }

  /** Excel H123 verdict is on DSR only - the NDI floor is returned for
      display but does not flip the verdict (matches the master Excel). */
  function pfVerdict(grossIncome, customerClass, dsr, ndi) {
    var t = pfThreshold(grossIncome, customerClass);
    var ok = dsr <= t.threshold;
    return {
      verdict: ok ? VERDICT.OK : VERDICT.DSR_BURST,
      threshold: t.threshold, ndiMin: t.ndiMin, ndiOk: ndi >= t.ndiMin
    };
  }

  /** PF stress-test verdict: TYPE A also uses 70/75% in the stress block
      (04 section 6). No NDI floor stated for the stress block. */
  function pfStressVerdict(grossIncome, dsr) {
    var thr = grossIncome < 10000 ? 0.70 : 0.75;
    return { verdict: dsr <= thr ? VERDICT.OK : VERDICT.DSR_BURST, threshold: thr };
  }

  /** Unsecured new-DSR cap (List P14:Q17), fraction. */
  function unsecuredCap(grossIncome) {
    if (grossIncome >= 10001) return 0.70;
    if (grossIncome >= 6001) return 0.65;
    if (grossIncome >= 4500) return 0.60;
    return 0;
  }

  /** Max Unsecured Multiplier (MUM) by income bracket (List S/T, V/W). */
  function maxUnsecuredMultiplier(grossIncome) {
    if (grossIncome > 15000) return 14;
    if (grossIncome > 10000) return 13;
    return 9;
  }

  /** PF eligibility gate (Excel H113) - bands on GROSS INCOME, not the
      requested amount:
        income < 3000           -> NOT ELIGIBLE
        income >= 5000          -> OK
        3000 <= income < 5000   -> requested amount must be <= the
          risk-grade limit (List!BC:BD); above it -> EXCEED LIMIT.
      gradeMax null (matrix not exported) -> band treated as OK. */
  function pfEligibilityGate(grossIncome, amount, gradeMax) {
    if (!grossIncome || grossIncome < 3000) return VERDICT.NOT_ELIGIBLE;
    if (grossIncome >= 5000) return VERDICT.OK;
    if (gradeMax != null && amount > gradeMax) return VERDICT.EXCEED_LIMIT;
    return VERDICT.OK;
  }

  Engine.VERDICT = VERDICT;
  Engine.hfThreshold = hfThreshold;
  Engine.hfVerdict = hfVerdict;
  Engine.pfThreshold = pfThreshold;
  Engine.pfVerdict = pfVerdict;
  Engine.pfStressVerdict = pfStressVerdict;
  Engine.unsecuredCap = unsecuredCap;
  Engine.maxUnsecuredMultiplier = maxUnsecuredMultiplier;
  Engine.pfEligibilityGate = pfEligibilityGate;

  /* ---------- formatting helpers (shared) ---------- */
  Engine.formatCurrency = function (v, dashZero) {
    var n = parseFloat(v);
    if (!isFinite(n) || (dashZero !== false && n === 0)) return '-';
    return 'RM ' + n.toLocaleString('en-MY', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    });
  };
  Engine.formatPct = function (fraction, dp) {
    var n = parseFloat(fraction);
    if (!isFinite(n)) return '-';
    return (n * 100).toFixed(dp == null ? 1 : dp) + '%';
  };
})();
