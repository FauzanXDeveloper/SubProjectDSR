/* ============================================================
   creditLimit.js - Credit Card limit & eligibility (CC-only)
   Source: credit_card.txt section 5 (creditLimit.ts port)
   ============================================================ */
(function () {
  'use strict';
  window.Engine = window.Engine || {};

  var CARD_MAX = 400000;

  // BOTH = apply for Platinum AND Signature on ONE shared limit. The limit,
  // instalment and DSR are computed once (never two). To qualify for both the
  // applicant must clear the higher bar, so BOTH takes Signature's RM4,000
  // floor and still respects the Platinum salary cap - the conservative mix.
  function cardMin(product) {
    return (product === 'VISA_SIGNATURE' || product === 'BOTH') ? 4000 : 2000;
  }

  /** Multiplier from Experian iScore risk-grade bands. null = not eligible. */
  function multiplierFromIScore(iScore) {
    var s = parseFloat(iScore);
    if (!isFinite(s) || s < 605) return null;   // <51 missing, 51-604 RG1-RG4
    if (s <= 619) return 3;   // RG5
    if (s <= 634) return 4;   // RG6
    if (s <= 649) return 5;   // RG7
    if (s <= 664) return 6;   // RG8
    if (s <= 679) return 7;   // RG9
    return 8;                 // RG10 (680+)
  }

  /** Credit-card Risk Grade label from the Experian iScore. NOTE: this is
      the CARD scorecard grade (RG5-RG10 eligible), which is NOT the same
      banding as the PF/iScore risk grade in ndiPricing.js. Returns null
      when the score is missing/invalid. */
  function cardRiskGrade(iScore) {
    var s = parseFloat(iScore);
    if (!isFinite(s) || s < 51) return null;
    if (s < 605) return 'RG1-RG4';   // 51-604: below the card cut-off
    if (s <= 619) return 'RG5';
    if (s <= 634) return 'RG6';
    if (s <= 649) return 'RG7';
    if (s <= 664) return 'RG8';
    if (s <= 679) return 'RG9';
    return 'RG10';                    // 680+
  }

  /** CC DSR threshold (%) by gross income band. */
  function ccDsrThreshold(grossIncome) {
    if (grossIncome < 5000) return 60;
    if (grossIncome <= 10000) return 70;
    return 75;
  }

  /**
   * Full limit computation.
   * Returns { multiplier, rawMaxLimit, maxCreditLimit, isEligibleByLimit,
   *           monthlyInstallment, cardMin, cardMax }
   */
  function calculateMaxCreditLimit(grossIncome, iScore, product) {
    var multiplier = multiplierFromIScore(iScore);
    var roundedGross = Math.floor((grossIncome || 0) / 100) * 100;
    var rawMaxLimit = multiplier
      ? Math.floor(roundedGross * multiplier / 1000) * 1000 : 0;

    // Salary cap: Visa Platinum (and BOTH, which includes Platinum),
    // gross RM2,000-RM3,000
    var capped = rawMaxLimit;
    if ((product === 'VISA_PLATINUM' || product === 'BOTH') && grossIncome >= 2000 && grossIncome <= 3000) {
      capped = Math.min(rawMaxLimit, grossIncome * 2);
    }

    var maxCreditLimit = Math.min(capped, CARD_MAX);
    var min = cardMin(product);
    var isEligibleByLimit = multiplier !== null && maxCreditLimit >= min;
    var monthlyInstallment = Math.ceil(maxCreditLimit * 0.01);

    return {
      multiplier: multiplier,
      rawMaxLimit: rawMaxLimit,
      maxCreditLimit: maxCreditLimit,
      isEligibleByLimit: isEligibleByLimit,
      monthlyInstallment: monthlyInstallment,
      cardMin: min,
      cardMax: CARD_MAX
    };
  }

  /** Instalment/eligibility for an officer-proposed limit. */
  function evaluateProposedLimit(proposedLimit, product) {
    var limit = parseFloat(String(proposedLimit == null ? '' : proposedLimit).replace(/[,\s%]/g, '')) || 0;
    var min = cardMin(product);
    return {
      maxCreditLimit: limit,
      monthlyInstallment: Math.ceil(limit * 0.01),
      isEligibleByLimit: limit >= min && limit <= CARD_MAX,
      cardMin: min,
      cardMax: CARD_MAX
    };
  }

  Engine.CARD_MAX = CARD_MAX;
  Engine.cardMin = cardMin;
  Engine.multiplierFromIScore = multiplierFromIScore;
  Engine.cardRiskGrade = cardRiskGrade;
  Engine.ccDsrThreshold = ccDsrThreshold;
  Engine.calculateMaxCreditLimit = calculateMaxCreditLimit;
  Engine.evaluateProposedLimit = evaluateProposedLimit;
})();
